from django import forms
from django.core.exceptions import ValidationError
from django.core.validators import EmailValidator
from .models import UserProfile

class RegistrationForm(forms.ModelForm):
    password1 = forms.CharField(widget=forms.PasswordInput, label='Password')
    password2 = forms.CharField(widget=forms.PasswordInput, label='Confirm Password')

    class Meta:
        model = UserProfile
        fields = ['name', 'email', 'phone_number', 'address', 'city', 'pin_code', 'landmark']

    def clean_email(self):
        email = self.cleaned_data['email']
        email_validator = EmailValidator(message='Enter a valid email address.')
        try:
            email_validator(email)
        except ValidationError:
            raise ValidationError("Please enter a valid email address.")
        return email

    def clean_password2(self):
        password1 = self.cleaned_data.get('password1')
        password2 = self.cleaned_data.get('password2')

        if password1 and password2 and password1 != password2:
            raise ValidationError("Passwords do not match")

        return password2

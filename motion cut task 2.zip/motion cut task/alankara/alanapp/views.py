from django.shortcuts import render,redirect
from .forms import RegistrationForm

def home(request):
    return render(request, 'home.html')

def services(request):
    return render(request, 'services.html', {'services': services})

def about(request):
    return render(request, 'about.html')

def contact(request):
    return render(request, 'contact.html')

from django.contrib import messages

def register(request):
    if request.method == 'POST':
        form = RegistrationForm(request.POST)
        if form.is_valid():
            user_profile = form.save(commit=False)
            user_profile.save()
            messages.success(request, 'Registration successful. You can now log in.')
            return render(request, 'success.html')
        else:
            messages.error(request, 'Fill all the required fields')
    else:
        form = RegistrationForm()

    return render(request, 'register.html', {'form': form})


